#include <stdio.h>

#define START_COL 29
#define FINISH_COL 53

#define OUT_FILENAME "convert.dat"

#define DEFAULT_ERROR 0.2
#define LARGE_ERROR 0.5

int main (int argc, char **argv)
{
  int c, isLargeErr = 0, i ;
  FILE *fin, *fout ;

  if (argc != 2)
    {
      printf ("Usage:  %s <light curve filename>\n", argv[0]) ;
      (void)getc(stdin) ;
      return (1) ;
    }

  fin = fopen (argv[1], "rt") ;

  if (!fin)
    {
      printf ("ERROR: Input file not found ('%s')\n", argv[1]) ;
      (void)getc(stdin) ;
      return (2) ;
    }

  fout = fopen (OUT_FILENAME, "wt") ;

  if (!fout)
    {
      fclose (fin) ;
      printf ("ERROR: Output file not found ('%s')\n", OUT_FILENAME) ;
      (void)getc(stdin) ;
      return (3) ;
    }


  i = 0 ;
  while ((c = fgetc(fin)) != EOF)
    {
      i++ ;

      if (c == '*') break ;

      if (c == '\n')
	{
	  i = 0 ;

	  if (isLargeErr)
	    fprintf (fout,"  %f\n", LARGE_ERROR) ;
	  else
	    fprintf (fout,"  %f\n", DEFAULT_ERROR) ;

	  isLargeErr = 0 ;
	}
      else
	if ((i >= START_COL) && (i <= FINISH_COL))
	  {
	    if (((c >= '0') && (c <= '9')) || (c == '.') || (c == '-') || (c == ' '))
	      fputc (c, fout) ;
	    else
	      isLargeErr = 1 ;  // should be for c = ':', '<', '>'
	  }
    }

  fclose (fin) ;
  fclose (fout) ;

  printf ("done.\n") ;
  (void)getc(stdin) ;
  return (0) ;
}
