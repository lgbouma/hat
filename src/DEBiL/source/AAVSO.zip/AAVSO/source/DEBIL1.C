/******************************************************************************************
 *
 * Welcome to the DEBiL fitter  (Detached Eclipsing Binary Light-curve fitter)
 * Written by Jonathan Devor (CfA), 9 May 2004
 *
 * This program fits a given light curve to a model of a binary star system
 * It uses the downhill simplex method (Nelder and Mead) with simulated annealing
 * for multidimensional continuous optimization (minimization)
 *
 * The fitter makes the following assumptions-
 *
 * 1. Both stars are spherical:
 *      - Detached binary system --> negligible tidal bulge (in Roche lobe)
 *      - Slow rotation --> negligible centripetal deformation
 *
 * 2. Both stars have a Sun-like photosphere:
 *      - Solar limb darkening --> proportional scaling in size and flux per area
 *         (from Astrophysical Quantities by C.W. Allen)
 *      - Detached binary system --> negligible gravity darkening
 *      - Homogeneous --> small star spots and flares
 *
 *******************************************************************************************/

#define VERSION "1.0"
#define DEFAULT_NUM_ITERATIONS 10000

// Quadratic limb darkening parameters: (Solar V-band)
#define DEFAULT_LIMB_QUAD_A 0.5347 //   [Claret 2003]
#define DEFAULT_LIMB_QUAD_B 0.1792

#include <stdio.h>
#include <stdlib.h>
#include "period_l.h"
#include "debil_l.h"

int main (int argc, char **argv)
{
  FILE *fin ;
  long numIterations = DEFAULT_NUM_ITERATIONS ;
  double period, quadA = DEFAULT_LIMB_QUAD_A, quadB = DEFAULT_LIMB_QUAD_B ;

  //----------
  //  argc = 2 ;
  //  argv[1] = "convert.dat" ;
  //----------


  if ((argc != 2) && (argc != 3))
    {
      printf ("Usage: %s <light curve filename> [period]\n", argv[0]) ;
      (void)getc(stdin) ;
      return (1) ;
    }

  if (!(fin = fopen (argv[1], "rt")))
    {
      printf("ERROR: Can't open input file ('%s')", argv[1]) ;
      (void)getc(stdin) ;
      return (2) ;
    }


  if (argc > 2)
    {
      period = atof (argv[2]) ;

      if (period <= 0.0)
      {
       fclose (fin) ;
       printf ("ERROR: Invalid period (%f)\n", period) ;
       (void)getc(stdin) ;
       return (3) ;
      }
    }
  else
    {
      printf ("\n\n Looking for the period...\n\n") ;
      period = periodS2(fin) ;

      if (period == 0.0)
      {
       fclose (fin) ;
       printf("ERROR: Couln't find the period\n") ;
       (void)getc(stdin) ;
       return (4) ;
      }
    }

  rewind(fin) ;

  printf ("\n\n Fitting to an eclipsing binary model...\n\n") ;
  DEBiL (fin, period, numIterations, quadA, quadB) ;

  fclose (fin) ;

  printf ("\n\n------------\n") ;
  printf (" The Detached Eclipsing Binary Light curve fitter (DEBiL)\n") ;
  printf (" created by Jonathan Devor (Harvard-Smithsonian Center for Astrophysics)\n") ;
  printf (" for more details:  http://cfa-www.harvard.edu/~jdevor/DEBiL.html\n") ;

  (void)getc(stdin) ;

  return (0) ;
}
